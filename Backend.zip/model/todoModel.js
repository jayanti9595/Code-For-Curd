const mongoose = require("mongoose");

var todoSchema = mongoose.Schema(
  {
    task: {
      type: String,
      required: [true, "task Required"],
    },
    description: {
      type: String,
      required: [true, "description Required"],
      unique: true,
    },
    status: {
      type: String,
      enum: ["pending", "completed"],
      default: "pending",
    },
  },
  { versionKey: false }
);

module.exports = mongoose.model("todoSchema", todoSchema, "todo");
