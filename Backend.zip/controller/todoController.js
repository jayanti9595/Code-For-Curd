const TodoModel = require('../model/todoModel');

const getTodoData = async (request, response) => {
    try {
        const todo_data = await TodoModel.find({}); // Fetch all todo records
        return response.status(200).json({ status: true, todo_data });
    } catch (error) {
        console.error("Error fetching todo data:", error.message); // Helpful during debugging
        return response.status(500).json({ status: false, error: error.message });
    }
};

const addTodo = async (request, response) => {
    try {
        const { task, description } = request.body;
        if (!task) {
            return response.status(400).json({ status: false, msg: "Task field is required" });
        }
        if (!description) {
            return response.status(400).json({ status: false, msg: "description field is required" });
        }
        const newTodo = new TodoModel({task,description});
        const savedTodo = await newTodo.save();
        return response.status(200).json({ status: true, msg: "Todo added successfully", todo: savedTodo });
    } catch (error) {
        return response.status(500).json({ status: false, error: error.message });
    }
};


const editTodo = async (request, response) => {
    try {
        const { todo_id, task, description, status } = request.body;
        if (!todo_id) {
            return response.status(400).json({ status: false, msg: "todo_id is required" });
        }
        const updatedFields = {};
        if (task) updatedFields.task = task;
        if (description) updatedFields.description = description;
        if (status) updatedFields.status = status;

        const updatedTodo = await TodoModel.findByIdAndUpdate(todo_id,{ $set: updatedFields },{ new: true });
        if (!updatedTodo) {
            return response.status(404).json({ status: false, msg: "Todo not found" });
        }
        return response.status(200).json({ status: true, msg: "Todo updated successfully", todo: updatedTodo });
    } catch (error) {
        return response.status(500).json({ status: false, error: error.message });
    }
};

const deleteTodo = async (request, response) => {
    try {
        const { todo_id } = request.body.data;
        console.log("todo_id",todo_id);
        
        if (!todo_id) {
            return response.status(400).json({ status: false, msg: "todo_id is required" });
        }
        const deletedTodo = await TodoModel.findByIdAndDelete(todo_id);
        if (!deletedTodo) {
            return response.status(404).json({ status: false, msg: "Todo not found" });
        }
        return response.status(200).json({ status: true, msg: "Todo deleted successfully" });
    } catch (error) {
        return response.status(500).json({ status: false, error: error.message });
    }
};
const updateTodoStatus = async (request, response) => {
    try {
        const { todo_id, status } = request.body;
        if (!todo_id) {
            return response.status(400).json({ status: false, msg: "todo_id is required" });
        }
        const validStatus = ['pending', 'completed'];
        if (!validStatus.includes(status)) {
            return response.status(400).json({ status: false, msg: "Invalid status value" });
        }
        const updatedTodo = await TodoModel.findByIdAndUpdate(todo_id,{ $set: { status } },{ new: true });
        if (!updatedTodo) {
            return response.status(404).json({ status: false, msg: "Todo not found" });
        }
        return response.status(200).json({status: true,msg: "Todo status updated successfully",todo: updatedTodo});
    } catch (error) {
        return response.status(500).json({ status: false, error: error.message });
    }
};

const getSingleTodo = async (req, res) => {
  try {
    const { id } = req.params;

    const todo = await TodoModel.findById(id);

    if (!todo) {
      return res.status(404).json({ status: false, msg: "Todo not found" });
    }

    return res.status(200).json({ status: true, todo });
  } catch (error) {
    console.error("Error fetching single todo:", error.message);
    return res.status(500).json({ status: false, error: error.message });
  }
};
module.exports = { getTodoData, addTodo, deleteTodo, editTodo, updateTodoStatus,getSingleTodo};
