const mongoose = require('mongoose');
var url = "mongodb://localhost:27017/todo";

var connection = mongoose.connect(url).then(()=>{
    console.log("Connection to mongoose established successfully");
}).catch((err)=>{
    console.log("Error while connecting with mongoose : "+err);
});

module.export = connection;