const express = require('express');
const { getTodoData, addTodo, deleteTodo, editTodo, updateTodoStatus, getSingleTodo } =  require('../controller/todoController.js');
const upload = require('../controller/multer.js');
const userRouter = express.Router();

userRouter.get("/get_data",getTodoData);
userRouter.post("/add_todo",upload.none(),addTodo);
userRouter.post("/delete_todo",upload.none(),deleteTodo);
userRouter.post("/edit_todo",upload.none(),editTodo);
userRouter.post("/update_todo_status",updateTodoStatus);
userRouter.get('/get_todo/:id', getSingleTodo);
module.exports = userRouter;